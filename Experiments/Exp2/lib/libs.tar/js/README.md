### description

this folder contains JavaScript libraries, scripts and resources

### structure

[control](control) : Libraries to handle audio, fullscreen, time, ..<br>
[default](default) : Libraries used by template projects (and probably any task)<br>
[external](external) : External libraries (imported)<br>
[graphics](graphics) : Useful functions to draw stuff with Raphael<br>
[matlab](matlab) : <code>MATLAB</code> style functions<br>
